//
//  ViewController.swift
//  Calnew
//
//  Created by student on 2/3/2560 BE.
//  Copyright © 2560 MyCompany. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var st:Double = 0
    var nd:Double = 0
    var temp:Double = 0
    var tod:Double = 0
    var chnum:Int = 1
    var count:Int = 1
    var b:Int = 0
    var point:Double = 10
    var kept:Double = 10
    var chop:Int = 0
    var number1:String = ""
    var chpoint:Bool = true
    var check:Bool = false
    var op = 0
    @IBOutlet weak var eqLabel: UILabel!
    @IBAction func AC(_ sender: Any) {
        eqLabel.text  = "0"
        st = 0
        nd = 0
        op = 0
        chop = 0
        chpoint = true
        point = 10
        check = false
        chnum = 1
        count = 0
    }
    @IBAction func point(_ sender: Any) {
        if chpoint == true {
            chpoint = false
            point = 1
        }
    }
    @IBAction func btn1(_ sender: Any) {
        insert(1)
    }
    @IBAction func btn2(_ sender: Any) {
        insert(2)
    }
    @IBAction func btn3(_ sender: Any) {
        insert(3)
    }
    @IBAction func btn4(_ sender: Any) {
        insert(4)
    }
    @IBAction func btn5(_ sender: Any) {
        insert(5)
    }
    @IBAction func btn6(_ sender: Any) {
        insert(6)
    }
    @IBAction func btn7(_ sender: Any) {
        insert(7)
    }
    @IBAction func btn8(_ sender: Any) {
        insert(8)
    }
    @IBAction func btn9(_ sender: Any) {
        insert(9)
    }
    @IBAction func btn0(_ sender: Any) {
        insert(0)
    }
    @IBAction func btnadd(_ sender: Any) {
        if (chnum == 5 || chnum == 2 || chnum == 1) {
            count = count + 1
        st = oper()
        op = 1
        chnum = 1
        chop = 1
        chpoint = true
        point = 10
        check = true;
            if(st.truncatingRemainder(dividingBy: Double(1)) == 0){
                eqLabel.text = NSString (format : "%1.0f" , st) as String
            }else{
                eqLabel.text = String(st)
            }
        print("ST : \(st)  chnum : \(chnum) chop : \(chop) chnum : \(chnum)")
        }
    }
    @IBAction func btnmin(_ sender: Any) {
        if (chnum == 5 || chnum == 2 || chnum == 1){
            count = count + 1
        st = oper()
        op = 2
        chnum = 1
        chop = 2
        chpoint = true
        point = 10
        check = true;
            if(st.truncatingRemainder(dividingBy: Double(1)) == 0){
                eqLabel.text = NSString (format : "%1.0f" , st) as String
            }else{
                eqLabel.text = String(st)
            }
            
        print("ST : \(st)  chnum : \(chnum) chop : \(chop) chnum : \(chnum)")
        }
    }
    @IBAction func btntime(_ sender: Any) {
        if (chnum == 5 || chnum == 2 || chnum == 1){
            count = count + 1
        st = oper()
        op = 3
        chnum = 1
        chop = 3
        chpoint = true
        point = 10
        check = true;
            if(st.truncatingRemainder(dividingBy: Double(1)) == 0){
                eqLabel.text = NSString (format : "%1.0f" , st) as String
            }else{
                eqLabel.text = String(st)
            }
            
        print("ST : \(st)  chnum : \(chnum) chop : \(chop) chnum : \(chnum)")
        }
    }
    @IBAction func btndiv(_ sender: Any) {
        if (chnum == 5 || chnum == 2 || chnum == 1){
            count = count + 1
        st = oper()
        op = 4
        chnum = 1
        chop = 4
        chpoint = true
        point = 10
        check = true;
            if(st.truncatingRemainder(dividingBy: Double(1)) == 0){
                eqLabel.text = NSString (format : "%1.0f" , st) as String
            }else{
                eqLabel.text = String(st)
            }
        print("ST : \(st)  chnum : \(chnum) chop : \(chop) chnum : \(chnum)")
        }
    }
    func oper() -> Double{
        print("op : \(op) check  \(check) st : \(st)")
        if op == 0 { temp = Double(eqLabel.text!)! }
            else if(op == 1 ){
                temp =  Double(st) + Double(eqLabel.text!)!
            }
            else if (op == 2){
                if(st == 0){
                   temp = Double(eqLabel.text!)! - Double(st)
                }
                else{
                    temp =  Double(st) - Double(eqLabel.text!)!
                }
            }
            else if(op == 3 ){
                if(count < 1){
                    temp =  1 * Double(eqLabel.text!)!}
                else{
                    temp =  Double(st) * Double(eqLabel.text!)!}}
            else{
                if(count < 1){
                    temp = Double(eqLabel.text!)! / 1}
                else{
                    temp =  Double(st) / Double(eqLabel.text!)!
                }}
        return temp
    }
    @IBAction func eq(_ sender: Any) {
        if op == 1{
            nd = Double(eqLabel.text!)!
            st = st + nd
            print("ST : \(st)  chnum : \(chnum) chop : \(chop)")
        }
        if op == 2{
            nd = Double(eqLabel.text!)!
            st = st - nd
            print("ST : \(st)  chnum : \(chnum) chop : \(chop)")
        }
        if op == 3{
            nd = Double(eqLabel.text!)!
            st = st * nd
            print("ST : \(st)  chnum : \(chnum) chop : \(chop)")
        }
        if op == 4{
            nd = Double(eqLabel.text!)!
            st = st / nd
            print("ST : \(st)  chnum : \(chnum) chop : \(chop)")
        }
        if(op == 0 && chop != 0){
            if chop == 1{
                st = Double(eqLabel.text!)! + nd
                print("ST : \(st)  chnum : \(chnum) chop : \(chop) old")
            }
            if chop == 2{
                st = Double(eqLabel.text!)! - nd
                print("ST : \(st)  chnum : \(chnum) chop : \(chop) old")
            }
            if chop == 3{
                st = Double(eqLabel.text!)! * nd
                print("ST : \(st)  chnum : \(chnum) chop : \(chop) old")
            }
            if chop == 4{
                st = Double(eqLabel.text!)! / nd
                print("ST : \(st)  chnum : \(chnum) chop : \(chop) old")
            }
        }
        if(st.truncatingRemainder(dividingBy: Double(1)) == 0){
            eqLabel.text = NSString (format : "%1.0f" , st) as String
        }else{
        eqLabel.text = String(st)
        }
        check = false
        chnum = 2
        op = 0
        st = 0
        print("ST : \(st)  chnum : \(chnum) chop : \(chop)")
    }
    func insert( _ nu : Int ) {
        if chnum == 1{
        eqLabel.text = ""
        }
        if chnum == 2{
            st = 0
            eqLabel.text = ""
        }
        if chpoint == false{
        point = point / 10
            if eqLabel.text == "" { eqLabel.text = "0" }
        tod = Double(eqLabel.text!)! + Double(nu) * Double(point)
        number1 = String(tod)
        }
        else{
        number1 = eqLabel.text! + String(nu)
        }
        print(number1)
        eqLabel.text = number1
        check = false;
        chnum = 5
        print(st)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}
