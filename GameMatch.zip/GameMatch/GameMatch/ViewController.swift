//
//  ViewController.swift
//  GameMatch
//
//  Created by student on 2/17/2560 BE.
//  Copyright © 2560 MyCompany. All rights reserved.
//

import UIKit
    var arr = [#imageLiteral(resourceName: "Mercy.png"),#imageLiteral(resourceName: "Roadhog.png"),#imageLiteral(resourceName: "junkrat.png"),#imageLiteral(resourceName: "Mei.png"),#imageLiteral(resourceName: "Reaper.png"),#imageLiteral(resourceName: "Sombra.png"),#imageLiteral(resourceName: "Torbjorn.png"),#imageLiteral(resourceName: "Widow.png"),#imageLiteral(resourceName: "Winston.png"),#imageLiteral(resourceName: "Ana.png"),#imageLiteral(resourceName: "Mercy.png"),#imageLiteral(resourceName: "Roadhog.png"),#imageLiteral(resourceName: "junkrat.png"),#imageLiteral(resourceName: "Mei.png"),#imageLiteral(resourceName: "Reaper.png"),#imageLiteral(resourceName: "Sombra.png"),#imageLiteral(resourceName: "Torbjorn.png"),#imageLiteral(resourceName: "Widow.png"),#imageLiteral(resourceName: "Winston.png"),#imageLiteral(resourceName: "Ana.png")]
class ViewController: UIViewController {
    var time: Timer!
    var ctime: Timer!
    var myTime: Float = 0
    var myCount : Float = 0
    var count = 0
    var checktime : Bool = false
    var ctouch : Bool = true
    var win = 0
    var st = 0,nd = 0,ts = 0
    var btnarr:[UIButton] = [UIButton]()
    @IBOutlet weak var bar: UIProgressView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var Pic01: UIButton!
    @IBAction func btn_pic01(_ sender: Any) {
        check(0)
    }
    @IBOutlet weak var Pic02: UIButton!
    @IBAction func btn_pic02(_ sender: Any) {
        check(1)
    }
    @IBOutlet weak var Pic03: UIButton!
    @IBAction func btn_pic03(_ sender: Any) {
        check(2)
    }
    @IBOutlet weak var Pic04: UIButton!
    @IBAction func btn_pic04(_ sender: Any) {
        check(3)
    }
    @IBOutlet weak var Pic05: UIButton!
    @IBAction func btn_pic05(_ sender: Any) {
        check(4)
    }
    @IBOutlet weak var Pic06: UIButton!
    @IBAction func btn_pic06(_ sender: Any) {
        check(5)
    }
    @IBOutlet weak var Pic07: UIButton!
    @IBAction func btn_pic07(_ sender: Any) {
        check(6)
    }
    @IBOutlet weak var Pic08: UIButton!
    @IBAction func btn_pic08(_ sender: Any) {
        check(7)
    }
    @IBOutlet weak var Pic09: UIButton!
    @IBAction func btn_pic09(_ sender: Any) {
        check(8)
    }
    @IBOutlet weak var Pic10: UIButton!
    @IBAction func btn_pic10(_ sender: Any) {
        check(9)
    }
    @IBOutlet weak var Pic11: UIButton!
    @IBAction func btn_pic11(_ sender: Any) {
        check(10)
    }
    @IBOutlet weak var Pic12: UIButton!
    @IBAction func btn_pic12(_ sender: Any) {
        check(11)
    }
    @IBOutlet weak var Pic13: UIButton!
    @IBAction func btn_pic13(_ sender: Any) {
        check(12)
    }
    @IBOutlet weak var Pic14: UIButton!
    @IBAction func btn_pic14(_ sender: Any) {
        check(13)
    }
    @IBOutlet weak var Pic15: UIButton!
    @IBAction func btn_pic15(_ sender: Any) {
        check(14)
    }
    @IBOutlet weak var Pic16: UIButton!
    @IBAction func btn_pic16(_ sender: Any) {
        check(15)
    }
    @IBOutlet weak var Pic17: UIButton!
    @IBAction func btn_pic17(_ sender: Any) {
        check(16)
    }
    @IBOutlet weak var Pic18: UIButton!
    @IBAction func btn_pic18(_ sender: Any) {
        check(17)
    }
    @IBOutlet weak var Pic19: UIButton!
    @IBAction func btn_pic(_ sender: Any) {
        check(18)
    }
    @IBOutlet weak var Pic20: UIButton!
    @IBAction func btn_pic20(_ sender: Any) {
        check(19)
    }
    func check (_ ar : Int){
        if !ctouch && ar != st
        {
        if (count < 2) {
        count = count + 1
        btnarr[ar].setImage(arr[ar], for: .normal)
            if(count == 1) { st = ar }
        }
        if count == 2{
            ctouch = true
            ts = ar
                btnarr[ar].setImage(arr[ar], for: .normal)
            ctime = Timer.scheduledTimer(timeInterval: 0.2,target: self,selector: #selector(countTime),userInfo:nil,repeats: true)
        }
        }
    }
    @IBAction func start(_ sender: Any) {
        if(win == 0) {
        time = Timer.scheduledTimer(timeInterval: 1.0,target: self,selector: #selector(updateTime),userInfo:nil,repeats: true)
        checktime = true
        ctouch = false
        play()
        }
    }
    @IBAction func reset(_ sender: Any) {
        myTime = 0
        myCount = 0
        ctouch = true
        win = 0
        bar.setProgress(0.0, animated: true)
        if(checktime){
        time.invalidate()
            checktime = false
        }
        for a in btnarr {
            a.setImage(#imageLiteral(resourceName: "logo.jpg"), for: .normal)
            a.isHidden = false
        }
    }
    func updateTime(){
        if myTime == 60 { time.invalidate()
            ctouch = true
            alertwin()
        }
        else { print(myTime); myTime += 1 }
        bar.setProgress(myTime/60.0, animated: true)
    }
    func countTime(){
        if myCount == 0.5 {
            ctime.invalidate()
            myCount = 0
            if arr[ts] == arr[st]{
                btnarr[ts].isHidden = true
                btnarr[st].isHidden = true
                win = win+1
                ctouch = false
                if win == 10 {
                    time.invalidate()
                    alertwin()
                }
            }
            else if arr[ts] != arr[st]{
                btnarr[ts].setImage(#imageLiteral(resourceName: "logo.jpg"), for: .normal)
                btnarr[st].setImage(#imageLiteral(resourceName: "logo.jpg"), for: .normal)
                ctouch = false
            }
            st = -1
            ts = 0
            count = 0
        }
        else { print("\(myCount) check"); myCount += 0.5 }
    }
    func alertwin(){
        let alert = UIAlertController(title:"Win!!",message:"you got \(60-myTime + Float(win) * 2) in 80",preferredStyle: .alert)
        let alertbtn = UIAlertAction(title:"K.O.",style: .default,handler : nil)
        alert.addAction(alertbtn)
        self.present(alert,animated: true,completion: nil)
        label.text = "Your score : \(60-myTime + Float(win) * 2)"
    }
    func play(){
        for _ in 0..<arr.count{
            arr.sort { (_,_) in arc4random() < arc4random() }
        }
        print(arr)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        bar.setProgress(0.0, animated: true)
        self.btnarr = [self.Pic01,self.Pic02,self.Pic03,self.Pic04,self.Pic05,self.Pic06,self.Pic07,self.Pic08,self.Pic09,self.Pic10,self.Pic11,self.Pic12,self.Pic13,self.Pic14,self.Pic15,self.Pic16,self.Pic17,self.Pic18,self.Pic19,self.Pic20]
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

